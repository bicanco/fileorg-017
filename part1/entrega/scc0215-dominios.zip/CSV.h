/*==============================================================*\
||  Primeiro Trabalho Prático - Organização de Arquivos(SCC215) ||
||   															||
|| Alunos:  									Nº USP: 	    ||
||   	David Souza Rodrigues							4461180 ||
||   	Fernanda Tostes Marana  						4471070 ||
||   	Gabriel Toschi de Oliveira  					9763039 ||
||   	Marcelo de Moraes Carvalho da Silva 			9791048 ||
||   															||
|| Professora:  												|| 
||   	Dra. Cristina Dutra de Aguiar Ciferri  					||
||   															||
|| Entrega:														|| 
||     	09/05/2017				 								||
||   															||
||  Arquivo: 													||
||   		CSV.h												||
||   															||
||	Descrição:													||
||		Funções que manipulam arquivos CSV para leitura e 		||
||		escrita.												||
\*==============================================================*/

#ifndef _CSV_H_
#define _CSV_H_

char **leCSV(FILE *);
void liberaCSV(char **);

#endif
